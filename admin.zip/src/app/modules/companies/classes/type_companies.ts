export enum TypesCompanies{
    admin ="ADMIN",
    vendeur="VENDEUR",
    livreur="LIVREUR"
}
export enum TypesRoles{
    admin ="ADMIN",

}