import { Middlewares } from '../../base/middleware';

export class PartMiddlewares extends Middlewares{
    accessMethods = ['']
 
}
export const middleware = new PartMiddlewares()