export enum Emplacement{
    CHER_VENDEUR="CHER_VENDEUR",
    CHER_CLIENT="CHER_CLIENT"
}