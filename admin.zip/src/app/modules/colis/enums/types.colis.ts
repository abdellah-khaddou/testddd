export enum TypesColisEnum{
    STANDARD="STANDARD",
    WHEREHOUSE="WHERHOUSE"
}
export enum SubTypesColisEnum{
    NORMAL="NORMAL",
    REMBERCEMENT="REMBERCEMENT",
    ECHANGE="ECHANGE"
}