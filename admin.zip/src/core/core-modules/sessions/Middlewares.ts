
        import { stageRequest, stageResponse } from "../../../core/interfaces/Request";

        export  function midExample(req:stageRequest,res:stageResponse){
            console.log('midExample Was Called')
          } 