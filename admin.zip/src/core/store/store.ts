export class Store {
    constructor(){ }
} 