import {Document, DocumentQuery, Model, model as _model, Schema} from 'mongoose';

 // model
// export function kmModel (_name: string, _schema?: Schema<any> | undefined, _collection?: string | undefined, _skipInit?: boolean | undefined) : Model<Document> {
// //    let extendedModel = 
// let {findOne,updateOne ,$where,addListener,aggregate,base,baseModelName,bulkWrite,collection,count,countDocuments,create,createCollection,createIndexes,db,deleteMany,deleteOne ,discriminator,discriminators,distinct,emit,ensureIndexes,estimatedDocumentCount,eventNames,exists,find,findById,findByIdAndDelete,findByIdAndRemove,findByIdAndUpdate,findOneAndDelete,findOneAndRemove,findOneAndUpdate,geoSearch,getMaxListeners,hydrate,init,insertMany,listIndexes,listenerCount,listeners,mapReduce,modelName,on,populate,model,off,once,prependListener,prependOnceListener,rawListeners,remove,removeAllListeners,removeListener,replaceOne,setMaxListeners,syncIndexes,translateAliases,update,updateMany,watch,where,schema}= _model(_name,_schema,_collection,_skipInit);
//  let objectToReturn = {findOne,updateOne ,$where,addListener,aggregate,base,baseModelName,bulkWrite,collection,count,countDocuments,create,createCollection,createIndexes,db,deleteMany,deleteOne ,discriminator,discriminators,distinct,emit,ensureIndexes,estimatedDocumentCount,eventNames,exists,find,findById,findByIdAndDelete,findByIdAndRemove,findByIdAndUpdate,findOneAndDelete,findOneAndRemove,findOneAndUpdate,geoSearch,getMaxListeners,hydrate,init,insertMany,listIndexes,listenerCount,listeners,mapReduce,modelName,on,populate,model,off,once,prependListener,prependOnceListener,rawListeners,remove,removeAllListeners,removeListener,replaceOne,setMaxListeners,syncIndexes,translateAliases,update,updateMany,watch,where,schema};
//     return objectToReturn;    
// }
  
// let kmModel
// export let  modelDB :kmModel ;
// mongoose.model = "" 