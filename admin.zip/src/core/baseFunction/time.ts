interface dateInterval{
    start:Date;
    end:Date;

}
class DateTime{
    getMonthsOfPeriod(interval:dateInterval){
        interval.start.getMonth()
        interval.start.getFullYear()
        interval.start.getMonth()
    }
    getWeeksOfPeriod(){

    }
    getDaysOfPeriod(){}
}
